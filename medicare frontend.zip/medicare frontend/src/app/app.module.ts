import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './medicare/register.component';
import { LoginComponent } from './medicare/login.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { ManagerComponent } from './medicare/manager.component';
import { CustomerComponent } from './medicare/customer.component';
import { LogoutComponent } from './medicare/logout.component';
import { AdddoctorsComponent } from './medicare/adddoctors.component';
import { AddmedicinesComponent } from './medicare/addmedicines.component';
import { DeletemedicinesComponent } from './medicare/deletemedicines.component';
import { DeletedoctorsComponent } from './medicare/deletedoctors.component';
import { CustomerviewdoctorsComponent } from './medicare/customerviewdoctors.component';
import { CustomerviewmedicinesComponent } from './medicare/customerviewmedicines.component';
import { ViewmedicinesComponent } from './medicare/viewmedicines.component';
import { ViewdoctorsComponent } from './medicare/viewdoctors.component';
import { UpdatemedicinesComponent } from './medicare/updatemedicines.component';
import { UpdatedoctorsComponent } from './medicare/updatedoctors.component';
import { SearchmedicinesComponent } from './medicare/searchmedicines.component';
import { SearchdoctorsComponent } from './medicare/searchdoctors.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    ManagerComponent,
    CustomerComponent,
    LogoutComponent,
    AdddoctorsComponent,
    AddmedicinesComponent,
    DeletemedicinesComponent,
    DeletedoctorsComponent,
    CustomerviewdoctorsComponent,
    CustomerviewmedicinesComponent,
    ViewmedicinesComponent,
    ViewdoctorsComponent,
    UpdatemedicinesComponent,
    UpdatedoctorsComponent,
    SearchmedicinesComponent,
    SearchdoctorsComponent
  ],
  imports: [
    BrowserModule,
  FormsModule,
    AppRoutingModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
