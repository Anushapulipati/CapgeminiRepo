import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customerviewdoctors',
  templateUrl: './customerviewdoctors.component.html',
  styleUrls: ['./customerviewdoctors.component.css']
})
export class CustomerviewdoctorsComponent implements OnInit {
data:any=[];
  constructor(private service:MedicareserviceService,private router:Router) { }
bookDoctor(){

}
  ngOnInit() {
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    })
   
  }

  onSearch(value){
    console.log(value);
   
    /* this.data=this.data.filter(b=>b.doctorName.toLowerCase().match(value.toLowerCase()) || b.doctorDisease.toLowerCase().match(value.toLowerCase()));
 */  /*   window.location.reload();  */
  }
  enter(value){
    localStorage.setItem("search",value);
    
console.log("serach value is"+value);
/* this.router.navigate(['/searchdoctors'])
 */this.data=this.data.filter(b=>b.doctorName.toLowerCase().match(value.toLowerCase()) || b.doctorDisease.toLowerCase().match(value.toLowerCase()));
 
  }
 
  }


