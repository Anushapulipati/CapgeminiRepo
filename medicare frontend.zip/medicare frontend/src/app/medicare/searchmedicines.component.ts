import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchmedicines',
  templateUrl: './searchmedicines.component.html',
  styleUrls: ['./searchmedicines.component.css']
})
export class SearchmedicinesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
