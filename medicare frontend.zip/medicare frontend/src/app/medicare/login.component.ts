import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  mobile:number;
  result:any;
  message:String;
  role:any;
  mob:any;
  constructor(private service:MedicareserviceService,private router:Router) { }
  check(mobile:number,password:String){
    
    console.log("login"+mobile+password);
      this.service.userlogin(mobile,password).subscribe((data:number)=>{this.result=data;
      console.log("loooo"+this.result);
      if(this.result==true){
        this.service.getRole(mobile).subscribe(data1=>{this.role=data1;
       
            if(this.role==1)
        {
        this.router.navigate(['/manager']);
        }
        else if(this.role==2){
          console.log("customer mobile"+mobile);
          this.mob=this.mobile;
          localStorage.setItem("mobile",this.mob);
          this.router.navigate(['/customer']);

        }
        else{
          this.router.navigate(['/logout'])
        }
      });
    }
    });
  
  }

  ngOnInit() {
  }

}
