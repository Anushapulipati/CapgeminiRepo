import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-searchdoctors',
  templateUrl: './searchdoctors.component.html',
  styleUrls: ['./searchdoctors.component.css']
})
export class SearchdoctorsComponent implements OnInit {
  data:any=[];
  data1:any=[];
  search:any;

  constructor(private service:MedicareserviceService) { }

  ngOnInit() {
    this.search=localStorage.getItem("search");
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    })
    this.data1=this.data.filter(b=>b.doctorName.toLowerCase().match(this.search.toLowerCase()) || b.doctorDisease.toLowerCase().match(this.search.toLowerCase()));

  }

}
