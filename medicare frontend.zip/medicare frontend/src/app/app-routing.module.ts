import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './medicare/register.component';
import { LoginComponent } from './medicare/login.component';
import { ManagerComponent } from './medicare/manager.component';
import { CustomerComponent } from './medicare/customer.component';
import { LogoutComponent } from './medicare/logout.component';
import { AdddoctorsComponent } from './medicare/adddoctors.component';
import { AddmedicinesComponent } from './medicare/addmedicines.component';
import { DeletedoctorsComponent } from './medicare/deletedoctors.component';
import { DeletemedicinesComponent } from './medicare/deletemedicines.component';
import { CustomerviewmedicinesComponent } from './medicare/customerviewmedicines.component';
import { CustomerviewdoctorsComponent } from './medicare/customerviewdoctors.component';
import { ViewmedicinesComponent } from './medicare/viewmedicines.component';
import { ViewdoctorsComponent } from './medicare/viewdoctors.component';
import { UpdatemedicinesComponent } from './medicare/updatemedicines.component';
import { UpdatedoctorsComponent } from './medicare/updatedoctors.component';
import { SearchdoctorsComponent } from './medicare/searchdoctors.component';


const routes: Routes = [
  {path:'userregister',component:RegisterComponent},
  {path:'userlogin',component:LoginComponent},
  {path:'manager',component:ManagerComponent},
  {path:'customer',component:CustomerComponent},
  {path:'adddoctors',component:AdddoctorsComponent},
  {path:'addmedicines',component:AddmedicinesComponent},
  {path:'deletedoctors',component:DeletedoctorsComponent},
  {path:'deletemedicines',component:DeletemedicinesComponent},
  {path:'viewmedicines',component:ViewmedicinesComponent},
  {path:'viewdoctors',component:ViewdoctorsComponent},
  {path:'customerviewmedicines',component:CustomerviewmedicinesComponent},
  {path:'customerviewdoctors',component:CustomerviewdoctorsComponent},
  {path:'updatemedicines',component:UpdatemedicinesComponent},
  {path:'updatedoctors',component:UpdatedoctorsComponent},
  {path:'searchdoctors',component:SearchdoctorsComponent},

  {path:'Logout',component:LogoutComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
