import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './medicare/register.component';
import { LoginComponent } from './medicare/login.component';
import { ManagerComponent } from './medicare/manager.component';
import { CustomerComponent } from './medicare/customer.component';
import { LogoutComponent } from './medicare/logout.component';
import { AdddoctorsComponent } from './medicare/adddoctors.component';
import { AddmedicinesComponent } from './medicare/addmedicines.component';
import { DeletedoctorsComponent } from './medicare/deletedoctors.component';
import { DeletemedicinesComponent } from './medicare/deletemedicines.component';


const routes: Routes = [
  {path:'userregister',component:RegisterComponent},
  {path:'userlogin',component:LoginComponent},
  {path:'manager',component:ManagerComponent},
  {path:'customer',component:CustomerComponent},
  {path:'adddoctors',component:AdddoctorsComponent},
  {path:'addmedicines',component:AddmedicinesComponent},
  {path:'deletedoctors',component:DeletedoctorsComponent},
  {path:'deletemedicines',component:DeletemedicinesComponent},

  {path:'Logout',component:LogoutComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
