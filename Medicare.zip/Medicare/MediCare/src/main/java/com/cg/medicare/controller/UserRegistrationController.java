package com.cg.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.medicare.dto.UserRegistration;
import com.cg.medicare.service.UserRegistrationService;

@RestController
@RequestMapping("/userregistration")
@CrossOrigin("http://localhost:4200")
public class UserRegistrationController {
	@Autowired
	UserRegistrationService userRegistrationService;

	
	@PostMapping("/addnewuser")
	public UserRegistration addUser(@RequestBody UserRegistration user){
		return userRegistrationService.addNewUser(user);
		
	}
	@GetMapping("/getuserrole/{mobile}")
	public Integer getUserRole(@PathVariable("mobile")Long mob) {
	
		String role=userRegistrationService.getRole(mob);
		System.out.println("role is"+role);
		if(role.equalsIgnoreCase("manager")) {
			return 1;
		}
		else if(role.equalsIgnoreCase("customer")) {
			return 2;
		}
			return 3;	
	}
	
	@GetMapping("/getallusers")
	public List<UserRegistration> getAllUsers(){
		return userRegistrationService.getAllUserDeatils();
	}
	
	@DeleteMapping("/deleteuser/{mobileNo}")
	public void deleteUser(@PathVariable("mobileNo")Long mobile)  {
		userRegistrationService.deleteUser(mobile);
		
	}
	
	@GetMapping("/validate/{mob}/{password}")
	public boolean login(@PathVariable("mob") Long mobile,@PathVariable("password") String password){
		return userRegistrationService.validateUserLogin(mobile, password);
		}
	
	
	@GetMapping("/getProductByMobileandanswer/{mob}/{ans}")
	public boolean validMobileandAnswer(@PathVariable("mob") Long mobile,@PathVariable("ans") String answer){
		return userRegistrationService.validateMobileandAnswer(mobile, answer);
		}
	
	@PutMapping("/updatepassword/{mob}/{pwd}")
	public void updatePassword(@PathVariable("mob") Long mobile,@PathVariable("pwd") String password){
		System.out.println(password); 
		userRegistrationService.updatepassword(mobile, password);
		}
	
	@GetMapping("/admindetails/{mob}/{password}")
	public Integer getAdminAndUserDetails(@PathVariable("mob") Long mobile,@PathVariable("password") String password){
		 String role=userRegistrationService.getAdminAndUserDetails(mobile, password);
		 System.out.println(mobile);
		 System.out.println("controller"+role);
		 if(role.equals("Admin")) {
			 return 1;
		 }
		 else if(role.equals("Customer")) {
			 return 2;
		}
	return 3;
}
	
	
}
