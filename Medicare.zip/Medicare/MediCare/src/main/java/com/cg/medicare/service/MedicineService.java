package com.cg.medicare.service;

import java.util.List;

import com.cg.medicare.dto.Medicines;

public interface MedicineService {
	public List<Medicines> showAllMedicines();
	public Medicines addMedicine(Medicines medicine);
	public List<Medicines> searchByMedicineName(String medicineName);
	public List<Medicines> searchByMedicineReason(String medicineReason);
	public void deleteMedicine(Long medicineId); 
	public Medicines updateMedicine(Long medicineId,Integer medicinePrice);
	


}
