package com.cg.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medicare.dao.UserRegistrationDao;
import com.cg.medicare.dto.UserRegistration;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService{
	@Autowired
	UserRegistrationDao userRegistrationDao;

	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		// TODO Auto-generated method stub
		return userRegistrationDao.validateMobileandAnswer(mobileno, answer);
	}

	@Override
	public boolean validateUserLogin(Long mobile, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.validateUserLogin(mobile, password);
	}

	@Override
	public UserRegistration addNewUser(UserRegistration user) {
		// TODO Auto-generated method stub
		return userRegistrationDao.addNewUser(user);
	}

	@Override
	public void updatepassword(Long mobile, String pwd) {
		// TODO Auto-generated method stub
		userRegistrationDao.updatepassword(mobile, pwd);
		
	}

	@Override
	public List<UserRegistration> getAllUserDeatils() {
		// TODO Auto-generated method stub
		return userRegistrationDao.getAllUserDeatils();
	}

	@Override
	public void deleteUser(Long mobileNo) {
		// TODO Auto-generated method stub
		userRegistrationDao.deleteUser(mobileNo);
		
	}

	@Override
	public String getAdminAndUserDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getAdminAndUserDetails(mobile, password);
	}

	@Override
	public String getRole(Long mobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getRole(mobile);
	}

}
