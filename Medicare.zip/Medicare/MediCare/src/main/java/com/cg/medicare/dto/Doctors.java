package com.cg.medicare.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "doctors_data")
public class Doctors {
	@Id
	@Indexed(name="_id")
	private Long doctorMobile;
	private String doctorName;
	private String doctorSpecalization;
	private String availableTiming;
	private String doctorLocation;
	private String doctorDisease;
	public Long getDoctorMobile() {
		return doctorMobile;
	}
	public void setDoctorMobile(Long doctorMobile) {
		this.doctorMobile = doctorMobile;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorSpecalization() {
		return doctorSpecalization;
	}
	public void setDoctorSpecalization(String doctorSpecalization) {
		this.doctorSpecalization = doctorSpecalization;
	}
	public String getAvailableTiming() {
		return availableTiming;
	}
	public void setAvailableTiming(String availableTiming) {
		this.availableTiming = availableTiming;
	}
	public String getDoctorLocation() {
		return doctorLocation;
	}
	public void setDoctorLocation(String doctorLocation) {
		this.doctorLocation = doctorLocation;
	}
	
	
	public String getDoctorDisease() {
		return doctorDisease;
	}
	public void setDoctorDisease(String doctorDisease) {
		this.doctorDisease = doctorDisease;
	}
	
	public Doctors(Long doctorMobile, String doctorName, String doctorSpecalization, String availableTiming,
			String doctorLocation, String doctorDisease) {
		super();
		this.doctorMobile = doctorMobile;
		this.doctorName = doctorName;
		this.doctorSpecalization = doctorSpecalization;
		this.availableTiming = availableTiming;
		this.doctorLocation = doctorLocation;
		this.doctorDisease = doctorDisease;
	}
	public Doctors() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Doctors [doctorMobile=" + doctorMobile + ", doctorName=" + doctorName + ", doctorSpecalization="
				+ doctorSpecalization + ", availableTiming=" + availableTiming + ", doctorLocation=" + doctorLocation
				+ ", doctorDisease=" + doctorDisease + "]";
	}
	
	
	
}
