package com.cg.medicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediCareApplication.class, args);
		System.out.println("medicare main application running");
	}

}
