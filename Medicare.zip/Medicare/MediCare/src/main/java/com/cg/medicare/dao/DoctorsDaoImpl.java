package com.cg.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.medicare.dto.Doctors;

@Repository
public class DoctorsDaoImpl implements DoctorsDao {
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public List<Doctors> showAllDoctors() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Doctors.class);
	}

	@Override
	public Doctors findDoctor(Long doctorMobile) {
		// TODO Auto-generated method stub
		List<Doctors> doctors=mongoTemplate.findAll(Doctors.class);
		for(Doctors details:doctors) {
			if(details.getDoctorMobile().equals(doctorMobile)) {
				return details;
			}
		
		}
		return null;
	}

	@Override
	public Doctors addDoctors(Doctors doctor) {
		// TODO Auto-generated method stub
		return mongoTemplate.insert(doctor);
	}

	
	@Override
	public void deleteDoctor(Long doctorMobile) {
		// TODO Auto-generated method stub
		List<Doctors> doctors=mongoTemplate.findAll(Doctors.class);
		for(Doctors details:doctors) {
			if(details.getDoctorMobile().equals(doctorMobile)) {
				System.out.println("in dao delete"+doctorMobile);
				mongoTemplate.remove(details);
			}
		}
		
	}

	@Override
	public Doctors updateDoctor(Long doctorMobile, String doctorTiming, String doctorLocation) {
		// TODO Auto-generated method stub
		Doctors doc=mongoTemplate.findById(doctorMobile, Doctors.class);
		doc.setAvailableTiming(doctorTiming);
		doc.setDoctorLocation(doctorLocation);
		mongoTemplate.save(doc);
		return doc;
		
	}

	@Override
	public List<Doctors> getDoctorByDisease(String doctorDisease) {
		// TODO Auto-generated method stub
		List<Doctors> doctor=mongoTemplate.findAll(Doctors.class);
		List<Doctors> doctor1=new ArrayList<>();
		for(Doctors details:doctor) {
			if(details.getDoctorDisease().equalsIgnoreCase(doctorDisease)) {
				doctor1.add(details);
			}
		}
		return doctor1;
	}

}
